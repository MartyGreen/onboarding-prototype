# T Design System

React компонент-библиотека для T Design System.

## Установка

### Требования
- React 16.8+
- React DOM 16.8+

Пакет публикуется в GitHub Packages. Перед установкой добавь registry для scope `@pluginwoman`:

```bash
npm config set @pluginwoman:registry https://npm.pkg.github.com
npm install @pluginwoman/t-ds
```

Подключи стили библиотеки один раз в корневом файле приложения:

```tsx
import '@pluginwoman/t-ds/style'
```

### Промпт для подключения дизайн-системы через ИИ-агента

Если нужно быстро подключить T Design System к новому проекту через агента (Claude Code, Cursor и др.), используй этот промпт:

```
Подключи T Design System (@pluginwoman/t-ds) к этому проекту:

1. Добавь в .npmrc строку: @pluginwoman:registry=https://npm.pkg.github.com
2. Установи пакет: npm install @pluginwoman/t-ds
3. Подключи стили один раз в корневом файле (App.tsx / main.tsx / layout.tsx):
   import '@pluginwoman/t-ds/style'
4. Добавь CSS-reset для корректного рендеринга шрифта в html или :root:
   -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;
5. Прочитай AGENTS.md из репозитория @pluginwoman/t-ds — там полный каталог
   компонентов, дизайн-токены и правила применения.

После подлючения прочитай файл AGENTS.md с инструкциями по использованию дизайн системы
```

## Использование

### Импорт компонентов

```tsx
import { Badge, Button, Input, Switch } from '@pluginwoman/t-ds'
import { Circle } from '@pluginwoman/t-ds/icons'
import '@pluginwoman/t-ds/style'

export function App() {
  return (
    <>
      <Button variant="primary">Нажми меня</Button>
      <Input placeholder="Введи текст" />
      <Switch />
      <Badge value={3} />
      <Circle />
    </>
  )
}
```

### Публичные entrypoints

- `@pluginwoman/t-ds` — компоненты библиотеки
- `@pluginwoman/t-ds/icons` — SVG-иконки
- `@pluginwoman/t-ds/style` — общие стили библиотеки

### Стили и токены

Пакет поставляется с CSS-переменными для цветов, типографики, отступов, скруглений, теней и иконок. Для корректной работы компонентов достаточно один раз импортировать:

```tsx
import '@pluginwoman/t-ds/style'
```

### Иконки

Иконки экспортируются отдельно из `@pluginwoman/t-ds/icons`:

```tsx
import { Circle } from '@pluginwoman/t-ds/icons'

export function Example() {
  return <Circle />
}
```

### Гайд для ИИ-агентов

В корне репозитория лежит [`AGENTS.md`](./AGENTS.md) — инструкция по применению дизайн-системы для ИИ-агентов (Claude Code, Cursor и др.). Файл описывает базовые правила, дизайн-токены (цвет, типографика, отступы, скругления, тени, иконки), каталог всех компонентов с ключевыми пропсами, типовые рецепты и чеклист перед сдачей UI. Большинство агентов подхватывают `AGENTS.md` автоматически; при сборке интерфейсов из этой библиотеки опирайся на него.

### Доступные компоненты

- **AccordeonCell** — ячейка с раскрывающимся содержимым
- **ActionFormCell** — ячейка формы с действием
- **ActionSheet** — нижняя панель действий
- **Alert** — короткое текстовое уведомление (success, error, neutral)
- **Avatar** — аватар пользователя
- **Badge** — бейдж количества
- **Button** — кнопка с вариантами (primary, secondary, transparent, white)
- **Cell** — базовая ячейка списка
- **CellLeftAccessory** — левый аксессуар ячейки
- **CellRightAccessory** — правый аксессуар ячейки
- **Checkbox** — чекбокс
- **Chip** — чип/тег с опциональной иконкой
- **ContextMenu** — контекстное меню
- **ContextualNotification** — контекстное уведомление с иконкой, действием и кнопкой закрытия
- **Drawer** — выезжающая панель
- **Dropdown** — выпадающий список
- **FeedbackBanner** — баннер обратной связи
- **Footer** — фиксированный подвал страницы с кнопками действий
- **FormCell** — ячейка формы со свитчером, чекбоксом или радио
- **FlowResultView** — экран результата флоу (успех / ошибка / ожидание), используется внутри Modal/Drawer
- **HeaderButton** — кнопка или группа кнопок под заголовком страницы
- **Input** — текстовое поле ввода
- **LinearProgress** — линейный индикатор прогресса
- **LinkCell** — ячейка-ссылка с заголовком, описанием и индикатором загрузки
- **MainPageNavigationBar** — главная навигационная панель сайта
- **Modal** — модальное окно
- **NavigationBar** — навигационная панель страницы с заголовком
- **PageAction** — строка действия или перехода на странице
- **PageLayout** — базовый макет страницы с навигацией и опциональной правой панелью
- **PromoPageBanner** — крупный визуальный блок-шапка для промо-страниц
- **PromoPageCard** — карточка для контентного наполнения промо-страниц
- **PromoPageHorizontalCard** — горизонтальная карточка на всю ширину для промо-страниц
- **Radio** — радиокнопка для единичного выбора
- **Spinner** — анимированный индикатор загрузки
- **Switch** — переключатель между двумя состояниями
- **Table** — грид-обёртка для таблицы из ячеек
- **TableCell** — ячейка таблицы с заголовком, описанием, тегом и аксессуарами
- **TabsCarousel** — горизонтальный скроллируемый список табов с анимацией переключения и поддержкой бейджей
- **Tag** — метка статуса или категории
- **TextArea** — многострочное поле ввода
- **Tooltip** — всплывающая подсказка
- **Widget** — блок-контейнер с заголовком и зоной для контента
- **WidgetTitle** — шапка виджета с заголовком и правым аксессуаром

## Лицензия

MIT — используй как хочешь в своих проектах
